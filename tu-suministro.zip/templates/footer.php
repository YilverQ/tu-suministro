<!-- Inicio -->
	<div class="margenTOP">
		<!-- Esto es la imagen circular que aparece en el footer -->
	</div>
	
	<footer>
		<div class="footerContent">
			<div class="bloqueFooter footername">
				<!-- Imagen Principal/Logo De La Empresa/Se puede cambiar la imagen -->
				<a href="/"><img src="img/logo-tu-suministro.png" alt="Tu Suministro Logo"/></a>
			</div>
			<div class="bloqueFooter contactofooter">
				<h3>Contacto.</h3>
				<ul>
					<li><b>Correos:</b></li>
					<li><b></b> tusuministrovzla@gmail.com</li>
					<li><b></b> tusuministro@hotmail.com</li>
					<li><b>Teléfono:</b> 0212-424-2684</li>
					<li><b>Whatsapp:</b> 0414-397-6743</li>
					<li><b>Ubicación:</b> Plaza Venezuela, Torre Lincoln.</li>
				</ul>
			</div>
			<div class="bloqueFooter redesfooter">
				<h3>Redes Sociales.</h3>
				<ul>
					<a href="https://www.facebook.com/129635842640282/" target="_blank"><li><i class="fa-brands fa-facebook-square"></i></li></a>
					<a href="https://instagram.com/tusuministro" target="_blank"><li><i class="fa-brands fa-instagram-square"></i></li></a>
				</ul>
			</div>
		</div>
		<div class="ultimo">
			<p>Copyright 2022 <i class="fa-solid fa-copyright"></i> - Tu Suministros - Todos Los Derechos Reservados.</p>
		</div>
	</footer>
<!-- Final -->